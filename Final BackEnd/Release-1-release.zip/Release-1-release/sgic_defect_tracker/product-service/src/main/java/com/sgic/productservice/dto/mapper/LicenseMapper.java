package com.sgic.productservice.dto.mapper;

public class LicenseMapper {

}

package com.sgic.productservice.dto;

public class LicenseNameDTO {
	private String licenseName;

	public String getLicenseName() {
		return licenseName;
	}

	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}
	
}

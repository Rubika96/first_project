package com.sgic.defect.server.controller;

public class DefectController {

}

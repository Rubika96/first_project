package com.sgic.defect.server.services;

public interface DefectService {

}

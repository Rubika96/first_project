package com.sgic.defect.server.services;

import org.springframework.stereotype.Service;

@Service
public class DefectServiceImplementation implements DefectService{

}

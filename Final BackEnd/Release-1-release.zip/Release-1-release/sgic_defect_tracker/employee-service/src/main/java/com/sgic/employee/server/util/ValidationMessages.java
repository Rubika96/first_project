package com.sgic.employee.server.util;

public class ValidationMessages {
	
	public static final String EMAIL_EXIST = "Email already exist";
	public static final String ADD_EMP = "Record Added Successfully";
	public static final String UPDATE_EMP = "Employee Updated Successfully";

}

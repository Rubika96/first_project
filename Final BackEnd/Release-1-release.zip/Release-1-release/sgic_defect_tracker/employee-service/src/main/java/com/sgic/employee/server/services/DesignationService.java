package com.sgic.employee.server.services;

import com.sgic.employee.server.entities.Designation;

public interface DesignationService {
	
	public Designation createDesignation(Designation designation);

}

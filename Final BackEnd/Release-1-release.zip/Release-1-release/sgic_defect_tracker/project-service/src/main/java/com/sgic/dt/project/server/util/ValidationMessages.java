package com.sgic.dt.project.server.util;

public class ValidationMessages {
	public static final String EMAIL_EXIST = "Email already exist";

}

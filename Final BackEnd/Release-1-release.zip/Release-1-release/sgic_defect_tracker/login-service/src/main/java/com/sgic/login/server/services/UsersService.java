package com.sgic.login.server.services;

public interface UsersService {
public boolean isEmailAlreadyExist(String email);
}

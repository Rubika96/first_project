package com.sgic.login.server.util;

public class ValidationMessages {
	public static final String EMAIL_EXIST = "Email already exist";

}

package com.sgic.login.server.services;

import java.util.List;

import com.sgic.login.server.entities.Role;
import com.sgic.login.server.entities.Users;

public interface RoleService {
public List<Role> getRole();

}

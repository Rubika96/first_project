package com.sgic.common.api.enums;

public enum Priority {

}
